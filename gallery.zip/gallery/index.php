<?php

// If there are many pictures it needs more time for thumbnails making
ini_set('max_execution_time', 0);

$settings = array(
	'page_tytle' => 'PAGE TYTLE',
	'page_bg' => 'img/bg.jpg',
	'img_next' => 'img/next.png',
	'img_prev' => 'img/prev.png',
	'img_download' => 'img/download.png',
	'orig_pic_dir' => 'pics/',
	'pic_dir' => 'pics2/',
	'thumb_dir' => 'thumbs/',
	'max_table_weight' => '1100px'
);

// Array of picture filenames in format ## "picture filename" => "picture text" 
$picture_captions = array(
	"" => ""
);


/*
========================
# Variables
========================
*/

// Filenames to be excluded in thumbnails creation
$exclude_arr = array(".","..",".htaccess");

// Getting the selected albums ID
if(isset($_GET['id'])) {
	$selected = $_GET['id'];
} else {
	$selected = "";
}

// Getting the selected album page
if(isset($_GET['page'])) {
	$page = $_GET['page'];
} else {
	$page = "0";
}

// Getting all pics in the image directory
if(is_dir($settings['pic_dir'])) {
	$dir_array = scandir($settings['pic_dir']);
}

// Counting how many pages are in the album
$max_page = round((count($dir_array) - 2) / 20) - 1;

// Putting the right next page and previous page
if($page < $max_page && $page != "0") {
	$next_page = $page + 1;
	$prev_page = $page - 1;
} elseif($page < $max_page && $page == "0") {
	$next_page = $page + 1;
	$prev_page = $max_page;
} else {
	$next_page = "0";
	$prev_page = $page - 1;
}


/*
========================
# Functions
========================
*/

function autoRotateImage($image) { 
    $orientation = $image->getImageOrientation(); 

    switch($orientation) { 
        case imagick::ORIENTATION_BOTTOMRIGHT: 
            $image->rotateimage("#000", 180); // rotate 180 degrees 
        break; 

        case imagick::ORIENTATION_RIGHTTOP: 
            $image->rotateimage("#000", 90); // rotate 90 degrees CW 
        break; 

        case imagick::ORIENTATION_LEFTBOTTOM: 
            $image->rotateimage("#000", -90); // rotate 90 degrees CCW 
        break; 
    } 

    // Now that it's auto-rotated, make sure the EXIF data is correct in case the EXIF gets saved with the image! 
    $image->setImageOrientation(imagick::ORIENTATION_TOPLEFT); 
}

function rotateImages($orig_pic_dir, $pic_dir, $exclude_arr) {
	// Getting all pics in the image directory
	if(is_dir($orig_pic_dir)) {
		$dir_array = scandir($orig_pic_dir);
	}

	if(count(scandir($orig_pic_dir)) != count(scandir($pic_dir))) {
		foreach ($dir_array as $image) {
			if(!in_array($image, $exclude_arr)) {
				$new_image = new Imagick($orig_pic_dir.$image);
				autoRotateImage($new_image);
			    $new_image->writeImage($pic_dir.$image);
			    $new_image->clear();
				$new_image->destroy();
			}
		}
	}
}

function generateThumbs($pic_dir, $thumb_dir, $exclude_arr) {
	// Getting all pics in the image directory
	if(is_dir($pic_dir)) {
		$dir_array = scandir($pic_dir);
	}

	foreach($dir_array as $image) {
		if(!in_array($image, $exclude_arr)) {
			$th_image = new Imagick($pic_dir.$image);
		    $th_image->thumbnailImage(200,0);
		    $th_image->writeImage($thumb_dir.$image);
		    $th_image->clear();
			$th_image->destroy();
		}
	}
}

/*
========================
# Fix image rotation
========================
*/
if(count(scandir($settings['orig_pic_dir'])) != count(scandir($settings['pic_dir']))) {
	rotateImages($settings['orig_pic_dir'], $settings['pic_dir'], $exclude_arr);
}

/*
========================
# Make Thumbnails
========================
*/

if(count(scandir($settings['pic_dir'])) != count(scandir($settings['thumb_dir']))) {
	generateThumbs($settings['pic_dir'], $settings['thumb_dir'], $exclude_arr);
}

?> 

<!doctype html>
<html lang="bg">
	<head>
		<title><?php echo $settings['page_tytle']; ?></title>
		<meta charset="utf-8">
		<script src="lightbox/js/jquery-1.11.0.min.js"></script>
		<script src="lightbox/js/lightbox.js"></script>
		<link href="lightbox/css/lightbox.css" rel="stylesheet" />
		<link href="style.css" rel="stylesheet" />
	</head>
	<body background="<?php echo $settings['page_bg']; ?>">
				<?php
					if(isset($dir_array)) {
						
						$dir_array = array_slice($dir_array, 2);
						$paged_array = array_chunk($dir_array, 20, true);
						
						$pagination = "<table align='center' class='pagination' style='width: ".$settings['max_table_weight'].";'>";
						$pagination .= "<tr><td style='width: 20%;'><a href='index.php?page=".$prev_page."'><img style='width:50px;' src='".$settings['img_prev']."' alt=''></a></td><td>";
						foreach($paged_array as $key => $value) {
							if(($key) % 20 == 0 && $key != 0) {
								if($key != $page) {
									$pagination .= "<br>";
									$pagination .= "<a href='index.php?page=".$key."'>".($key+1)."</a>&nbsp;&nbsp;&nbsp;";
								} else {
									$pagination .= "<br>";
									$pagination .= "<span style='color: red'>";
									$pagination .= $key+1;
									$pagination .= "</span>&nbsp;&nbsp;&nbsp;";
								}
							} else {
								if($key != $page) {
									$pagination .= "<a href='index.php?page=".$key."'>".($key+1)."</a>&nbsp;&nbsp;&nbsp;";
								} else {
									$pagination .= "<span style='color: red'>";
									$pagination .= $key+1;
									$pagination .= "</span>&nbsp;&nbsp;&nbsp;";
								}
							}
						}
						$pagination .= "</td><td style='width: 20%;'><a href='index.php?page=".$next_page."'><img style='width:50px;' src='".$settings['img_next']."' alt=''></a></td></tr></table>";

						//$html = $navigation."<br>";
						$html = $pagination;
						$html .= "<table align='center' cellspacing='15' class='maintable' style='width: ".$settings['max_table_weight'].";'>";
						echo $html;

						foreach($paged_array[$page] as $key => $file) {
							if(stripos($file, '.') > 0) {
								if(($key+1) % 4 == 0) {
									$output_html = "<td class='imagebox'><a href='".$settings['pic_dir'].$file."' rel='lightbox[roadtrip]'>";
									$output_html .= "<img style='width: 200px;' src='".$settings['thumb_dir'].$file."'></a><br>";
									if(isset($picture_captions[$file])) { $output_html .= $picture_captions[$file] . "<br>"; }
									$output_html .= "<a href='".$settings['pic_dir'].$file."' target='_blank'><img style='border: 0; height: 30px;' src='".$settings['pic_dir']."'></a>";
									$output_html .= "</td></tr>";
									$output_html .= "<tr>";
									echo $output_html;
								} else {
									$output_html = "<td class='imagebox'><a href='".$settings['pic_dir'].$file."' rel='lightbox[roadtrip]'>";
									$output_html .= "<img style='width: 200px;' src='".$settings['thumb_dir'].$file."'></a><br>";
									if(isset($picture_captions[$file])) { $output_html .= $picture_captions[$file] . "<br>"; }
									$output_html .= "<a href='".$settings['pic_dir'].$file."' target='_blank'><img style='border: 0; height: 30px;' src='".$settings['pic_dir']."'></a>";
									$output_html .= "</td>";
									echo $output_html;
								}
							}
						}
						echo "</table>";

						echo $pagination;
					} else {
						//echo $navigation;
					}
				?>
		</table>
	</body>
</html>